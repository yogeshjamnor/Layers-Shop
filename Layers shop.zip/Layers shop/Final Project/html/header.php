<?php
  
  require_once 'connection.php';

$sql_cart = "SELECT * FROM cart1";
$all_cart = $conn->query($sql_cart);


?>

<header class="header">

   <div class="flex">

      <a href="#" class="logo">Layers</a>

      <nav class="navbar">
                 <a href="/Final Project/index.php">view products</a>
      </nav>

      <?php
      
      $select_rows = mysqli_query($conn, "SELECT * FROM `cart1`") or die('query failed');
      $row_count = mysqli_num_rows($select_rows);

      ?>

      <a href="cart1.php" class="cart">cart <span><?php echo $row_count; ?></span> </a>

      <div id="menu-btn" class="fas fa-bars"></div>

   </div>

</header>