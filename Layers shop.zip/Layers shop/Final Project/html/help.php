<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="/Final Project/css/bootstrap/bootstrap.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <style>
        /* Contact CSS */
        
        .container {
            margin-top: 40px;
            margin-bottom: 130px;
        }
        
        .single-contact-info {
            position: relative;
            z-index: 1;
            background-color: #f8f8ff;
            padding: 30px;
            border-radius: 6px;
            margin-top: 10px;
        }
        
        .single-contact-info i {
            font-size: 2rem;
            margin-bottom: 1rem;
            display: block;
            color: #070a57;
        }
        
        .single-contact-info p {
            margin-bottom: 0;
        }
        
        .contact_from {
            position: relative;
            z-index: 1;
            margin-top: 6px;
        }
        
        .contact_from .form-control {
            font-size: 13px;
            height: 45px;
            padding: 5px 20px;
            border-color: #d6e6fb;
        }
        
        .contact_from .form-control:focus {
            border-color: #070a57;
        }
        
        .contact_from textarea.form-control {
            height: 200px;
            padding: 15px 20px;
        }
        
        .google-map {
            position: relative;
            z-index: 1;
            margin-top: 15px;
        }
        
        .google-map iframe {
            width: 100%;
            height: 300px;
            border: 0;
        }
    </style>
</head>

<body>

    <!-- Message Now Area -->

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 col-lg-6">
                <div class="popular_section_heading mb-50 text-center">
                    <h5 class="mb-3">Stay Conneted with us</h5>
                    
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-12 col-lg-4">
                <div class="single-contact-info mb-30">
                <i class="fa fa-phone"></i>
                    <p>+91 9112279190 </p>
                </div>
            </div>
            <div class="col-12 col-lg-4">
                <div class="single-contact-info mb-30">
                    <i class="fa fa-envelope"></i>
                    <p>yogeshjamnor@gmail.com <br> waheguru@gmail.com</p>
                </div>
            </div>
            <div class="col-12 col-lg-4">
                <div class="single-contact-info mb-30">
                    <i class="fa fa-fax"></i>
                    <p>+91 96874234 </p>
                </div>
            </div>

            <div class="col-12">
                <div class="contact_from mb-50">
                    <form action="help1.php" method="POST" >
                        <div class="contact_input_area">
                            <div id="success_fail_info"></div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <input type="text" class="form-control" name="name" placeholder="Enter Name" required>
                                    </div>
                                </div>
                                 <div class="col-md-6">
                                    <div class="form-group">
                                        <input type="email" class="form-control" name="email"  placeholder="Your E-mail" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <input type="text" class="form-control" name="subject"  placeholder="Subject" required>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="form-group">
                                        <textarea name="message" class="form-control"  cols="30" rows="10" placeholder="Your Message *" required></textarea>
                                    </div>
                                </div>
                                <div class="col-12 text-center">
                                    <input type="submit" name="submit" class="btn btn-primary w-100"placeholder="Send Message">
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <div class="col-12">
                <div class="google-map">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d736.7232820834313!2d73.80024680334944!3d18.64242446576879!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bc2b835d82e3b2b%3A0xd348e9c65a32ce85!2sASMS%20IBMR%20PUNE%20INSTITUTE%20OF%20BUSINESS%20MANAGEMENT%20AND%20RESEARCH%2C%20Indira%20Nagar%2C%20Anna%20Sahib%20Nagar%2C%20Chinchwad%2C%20Pimpri-Chinchwad%2C%20Maharashtra%20411019!5e0!3m2!1sen!2sin!4v1696846297519!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe></div>
            </div>
        </div>
    </div>


</body>

</html>