<html>
    <head>
    <link rel="stylesheet" href="\Final Project\php\assets\css\style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">
   
    </head>
<body>
<nav  class="navbar navbar-expand-lg navbar-light px-5" style="background-color: #3B3131;">
    
    <a class="navbar-brand ml-5" href="/Final Project/php/index.php">
        <img src="\Final Project\php\assets\images\logo.png" width="80" height="80">
    </a>
    <h1 style="border:1px solid; background-color:#8a7b6d; border-color:#3B3131;font-size:38px; ">Help Details</h1>
   
</nav>

<div id="ordersBtn" >
  
  <table class="table table-striped">
    <thead>
      <tr>
        <th>Name</th>
        <th>Email</th>
        <th>Subject</th>
        <th>Message</th>
     </tr>
    </thead>
     <?php
      include_once "../config/dbconnect.php";
      $sql="SELECT * from help";
      $result=$conn-> query($sql);
      
      if ($result-> num_rows > 0){
        while ($row=$result-> fetch_assoc()) {
    ?>
       <tr>
          <td><?=$row["name"]?></td>
          <td><?=$row["email_id"]?></td>  
         <td><?=$row["subject"]?></td>
          <td><?=$row["message"]?></td>
           
        </tr>
    <?php
            
        }
      }
    ?>
     
  </table>
   
</div>
</body>
</html>
