-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 15, 2023 at 08:58 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `admin`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart1`
--

CREATE TABLE `cart1` (
  `id` int(11) NOT NULL,
  `pname` varchar(60) NOT NULL,
  `quantity` int(2) NOT NULL,
  `price` int(6) NOT NULL,
  `total` int(10) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cart1`
--

INSERT INTO `cart1` (`id`, `pname`, `quantity`, `price`, `total`, `image`) VALUES
(8, 'Church', 1, 349, 0, '/Final Project/images/laptop/Church_icecy.png');

-- --------------------------------------------------------

--
-- Table structure for table `help`
--

CREATE TABLE `help` (
  `name` varchar(255) NOT NULL,
  `email_id` varchar(40) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `message` varchar(299) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `help`
--

INSERT INTO `help` (`name`, `email_id`, `subject`, `message`) VALUES
('Yogesh Jamnor', 'abc@gov.com', 'product not recieved', 'ghjghjhgjghjhjh');

-- --------------------------------------------------------

--
-- Table structure for table `home`
--

CREATE TABLE `home` (
  `product_id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `discount` int(11) DEFAULT NULL,
  `product_image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `home`
--

INSERT INTO `home` (`product_id`, `product_name`, `price`, `discount`, `product_image`) VALUES
(1, 'Blue Flower', 399, 26, '/Final Project/images/tablet/blue flower.jpg'),
(2, 'Captain America', 399, 60, '/Final Project/images/tablet/captain america.jpg'),
(4, 'Church', 349, 40, '/Final Project/images/laptop/Church_icecy.png'),
(5, 'Pink Drawing', 289, 25, '/Final Project/images/laptop/images (2).jpeg'),
(6, 'Batman', 229, 45, '/Final Project/images/mobile/batman.png'),
(7, 'Wolf King', 409, 20, '/Final Project/images/tablet/foxwan.jpg'),
(8, 'Pink Rose', 349, 29, '/Final Project/images/tablet/pink rose.jpg'),
(9, 'cupcake', 249, 45, '/Final Project/images/mobile/cupcake.png'),
(10, 'Work & Drecum', 319, 30, '/Final Project/images/laptop/images (3).jpeg\"'),
(11, 'Pirate Ship', 369, 42, '/Final Project/images/tablet/ship pirate.jpg'),
(12, 'Sun Star', 319, 26, '/Final Project/images/tablet/sun star.jpg'),
(13, 'Red Fire', 299, 25, '/Final Project/images/laptop/images (4).jpeg'),
(14, 'Pineapple', 209, 40, '/Final Project/images/mobile/pineapple.png'),
(15, 'pizza', 239, 30, '/Final Project/images/mobile/pizza.png'),
(16, 'Sticker', 389, 34, '/Final Project/images/tablet/kindpng_1209576.png');

-- --------------------------------------------------------

--
-- Table structure for table `laptop`
--

CREATE TABLE `laptop` (
  `product_id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `discount` int(11) DEFAULT NULL,
  `product_image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `laptop`
--

INSERT INTO `laptop` (`product_id`, `product_name`, `price`, `discount`, `product_image`) VALUES
(1, 'Apple Basic', 249, 39, '\\Final Project\\images\\laptop\\apple_basic.png');

-- --------------------------------------------------------

--
-- Table structure for table `layers`
--

CREATE TABLE `layers` (
  `name` varchar(20) NOT NULL,
  `email` varchar(40) NOT NULL,
  `password` varchar(20) NOT NULL,
  `usertype` varchar(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `layers`
--

INSERT INTO `layers` (`name`, `email`, `password`, `usertype`) VALUES
('namsjhd', 'abc@gov.com', '1234', 'user'),
('granthi', 'granthi@gmail.com', '1234', 'admin'),
('vedant', 'vedant@gmail.com', '1234', 'user'),
('Granthi', 'wareguru@gmail.com', '7890', 'admin'),
('Yogesh Jamnor', 'yogeshjamnor@gmail.com', '1234', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `mobile`
--

CREATE TABLE `mobile` (
  `product_id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `discount` int(11) DEFAULT NULL,
  `product_image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mobile`
--

INSERT INTO `mobile` (`product_id`, `product_name`, `price`, `discount`, `product_image`) VALUES
(1, 'Pine apple', 199, 49, '\\Final Project\\images\\mobile\\pineapple.png');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `name` varchar(40) NOT NULL,
  `number` int(20) NOT NULL,
  `email` varchar(40) NOT NULL,
  `method` varchar(20) NOT NULL,
  `flat` varchar(80) NOT NULL,
  `street` varchar(80) NOT NULL,
  `city` varchar(20) NOT NULL,
  `state` varchar(20) NOT NULL,
  `country` varchar(20) NOT NULL,
  `pin_code` int(8) NOT NULL,
  `total_products` int(11) NOT NULL,
  `total_price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`name`, `number`, `email`, `method`, `flat`, `street`, `city`, `state`, `country`, `pin_code`, `total_products`, `total_price`) VALUES
('granthi', 874646535, 'granthi@gmail.com', 'cash on delivery', '42', 'near airport nanded', 'nanded', 'maharashtra', 'India', 431605, 0, 399);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `product_id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `price` int(11) DEFAULT NULL,
  `discount` int(11) DEFAULT NULL,
  `product_image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`product_id`, `product_name`, `price`, `discount`, `product_image`) VALUES
(34, 'Galaxy', 249, 20, '/Final Project/images/tablet/galaxy.jpg'),
(36, 'Wait for me', 299, 12, '/Final Project/images/tablet/kindpng_2548340.png'),
(41, 'Captain America', 399, 39, '/Final Project/images/tablet/captain america.jpg'),
(43, 'Tom & Jerry', 299, 45, '/Final Project/images/tablet/tomjerry.jpg'),
(45, 'tom and jerry', 399, 45, '/Final Project/images/tablet/wallpaperflare.com_wallpaper.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart1`
--
ALTER TABLE `cart1`
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `home`
--
ALTER TABLE `home`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `layers`
--
ALTER TABLE `layers`
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD UNIQUE KEY `pin_code` (`pin_code`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`product_id`),
  ADD UNIQUE KEY `product_id` (`product_id`,`product_name`,`price`),
  ADD UNIQUE KEY `product_name` (`product_name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart1`
--
ALTER TABLE `cart1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `home`
--
ALTER TABLE `home`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
