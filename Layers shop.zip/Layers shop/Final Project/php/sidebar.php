<!-- Sidebar -->
<div class="sidebar" id="mySidebar">
<div class="side-header">
    <img src="./assets/images/logo.png" width="120" height="120"> 
    <h5 style="margin-top:10px;">Hello,Admin</h5>
    
</div>

<hr style="border:1px solid; background-color:#8a7b6d; border-color:#3B3131;">
    <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">×</a>
    <a href="/Final Project/html/logout.php" >Log-Out</a>
    <a href="register.php" >Add Admin</a>
     <a href="#customers"  onclick="showCustomers()" >Customers</a>
       <a href="#products"   onclick="showProductItems()" > Products</a>
    <a href="#orders" onclick="showOrders()"> Orders</a>
    <a href="\Final Project\php\adminView\help.php" onclick="showOrders()">Help</a>
    <a href="\Final Project\html\tablet_upload.php" onclick="showOrders()"> Upload Product</a>
  <!---->
</div>
 
<div id="main">
    <button class="openbtn" onclick="openNav()"><i class="fa fa-home"></i></button>
</div>


