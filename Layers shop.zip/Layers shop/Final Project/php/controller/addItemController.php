<?php 
  //creating connection to database
$con=mysqli_connect("localhost","root","","admin");

  //check whether submit button is pressed or not
if((isset($_POST['submit'])))
{
  //fetching and storing the form data in variables
$Id = $con->real_escape_string($_POST['id']);
$Name = $con->real_escape_string($_POST['name']);
$Price = $con->real_escape_string($_POST['price']);
$Discount = $con->real_escape_string($_POST['discount']);
$Image = $con->real_escape_string($_POST['image']);

  //query to insert the variable data into the database
$sql="INSERT INTO home (name, email_id, subject, message) VALUES ('".$Id."','".$Name."','".$Price."', '".$Discount."', '".$Image."',)";

  //Execute the query and returning a message
if(!$result = $con->query($sql)){
die('Error occured [' . $conn->error . ']');
}
else
   echo "Thank you! We will get in touch with you soon";
   header('location:\Final Project\index.php');
}

?>