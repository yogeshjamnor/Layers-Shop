function testNav() {
    document.getElementById("mySidenav").style.width = "300px";
}

function btnNav() {
    document.getElementById("mySidenav").style.width = "0px";
}