function myFUNCTION() {
    document.getElementById("myDropdown").classList.toggle("show");
}
window.onclick = function(event) {
    if (!event.target.matches(".dropbtn")) {
        var dropdowns = document.get
    }
}