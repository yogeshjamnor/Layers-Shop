
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Layers-shop</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

       <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">

</head>
<body>
            <div class="container-fluid position-fixed d-flex p-0">
          <!-- Sidebar Start -->
                <div class="sidebar pe-4 pb-3">
                    <nav class="navbar bg-secondary navbar-dark">
                        <a href="#" class="navbar-brand mx-4 mb-3">
                            <h3 class="text-primary" id="btn234" class="tablinks" onclick="openCity(event, 'home')">Layers</h3>
                        </a>
                        <div class="d-flex align-items-center ms-4 mb-4">
                            <div class="position-relative">
                                <a href="#"> <img class="rounded-circle" src="images/flower.jpg" alt="" style="width: 40px; height: 40px;"></a>
                                <div class="bg-success rounded-circle border border-2 border-white position-absolute end-0 bottom-0 p-1"></div>
                            </div>
                            
                        </div>
                        <div class="navbar-nav w-100">
                            <a href="#" class="nav-item nav-link " class="tablinks" onclick="openCity(event, 'home')"><i class="fa fa-tachometer-alt me-2"></i>Home</a>
                            <div class="nav-item dropdown">
                                <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown"><i class="fa fa-laptop me-2"></i>Devices</a>
                                <div class="dropdown-menu bg-transparent border-0">
                                    <a href="#" class="dropdown-item" id="tablink" onclick="openCity(event, 'mobile')">Smartphone</a>
                                    <a href="#" class="dropdown-item" id="tablink" onclick="openCity(event, 'laptop')">Laptop</a>
                                    <a href="#" class="dropdown-item" id="tablink" onclick="openCity(event, 'tablet')">Ipads & Tablets</a>
                                </div>
                            </div>                          
                            <a href="#" class="nav-item nav-link" id="tablink" onclick="openCity(event, 'apply')"><i class="fa fa-file me-2"></i>Apply Process</a>
                            <a href="#" class="nav-item nav-link" id="tablink" onclick="openCity(event, 'help')"><i class="fa fa-keyboard me-2"></i>Help & Support</a>
                            <a href="#" class="nav-item nav-link" id="tablink" onclick="openCity(event, 'about')"><i class="fa fa-info me-2"></i>About Us</a>                            
                        </div>
                    </nav>
                </div>
                <!-- Sidebar End -->


                <!-- Content Start -->
                <div class="content">
                    <!-- Navbar Start -->
                    <nav class="navbar navbar-expand bg-secondary navbar-dark sticky-top px-0 py-0">
                        <a href="#" class="navbar-brand d-flex d-lg-none me-4">
                            <h2 class="text-primary mb-3">Layers</h2>
                        </a>
                        <a href="#" class="sidebar-toggler flex-shrink-0 me-lg-4">
                            <i class="fa fa-bars"></i>
                        </a>
                            <div class="navbar-nav align-items-center ms-auto">
                            <div class="nav-item ">
                                <a href="html/cart1.php" class="dropdown-item " >
                                    <i class="fa fa-cart-arrow-down "><span class='badge badge-warning' id='lblCartCount'></span></i>
                                    <span class="d-none d-lg-inline-flex">Cart</span>
                                </a>
                            </div>                     

                            <div class="nav-item dropdown">
                                <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                                    <img class="rounded-circle me-lg-2" src="images/flower.jpg" alt="" style="width: 40px; height: 40px;">
                                   
                                </a>
                                <div class="dropdown-menu dropdown-menu-end bg-secondary border-0 rounded-0 rounded-bottom m-0">
                                 <a href="html\logout.php" class="dropdown-item">Log Out</a>
                                </div>
                            </div>
                        </div>
                    </nav>
                    <!-- Navbar End -->
                    <iframe src="html/products.php" width="100%"height=" 100%"id="home" class="tabcontent"></iframe>
                    <iframe src="html/phone.php" height="100%" width="100%" id="mobile" class="tabcontent"></iframe>
                    <iframe src="html/laptop.php" height="100%" width="100%" id="laptop" class="tabcontent"></iframe>
                    <iframe src="html/tablet.php" height="100%" width="100%" id="tablet" class="tabcontent"></iframe>
                    <iframe src="html/apply.php" height="100%" width="100%" id="apply" class="tabcontent"></iframe>
                   
                    <iframe src="html/help.php" height="100%" width="100%" id="help" class="tabcontent"></iframe>
                    <iframe src="html/about.php" height="100%" width="100%" id="about" class="tabcontent"></iframe>

                    <iframe src="html/account_details.php" height="100%" width="100%" id="profile" class="tabcontent"></iframe>


                </div>
              
            </div>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-latest.js"></script>
    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>